load val
f = figure('Visible','on')
[vpp,sig,mv,bound]=histfitlandau(val,3,0,1500);